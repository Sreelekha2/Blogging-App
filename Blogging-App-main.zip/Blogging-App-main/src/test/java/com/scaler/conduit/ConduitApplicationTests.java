package com.scaler.conduit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConduitApplicationTests {

    @Test
    void contextLoads() {
    }

}
